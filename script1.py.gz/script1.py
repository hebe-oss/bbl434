import sys
from Bio import SeqIO
from collections import Counter

# ---------------- CHECK INPUT ----------------
if len(sys.argv) < 2:
    print("Usage: python ori_signal_checker.py genomic.fa")
    sys.exit(1)

FASTA_FILE = sys.argv[1]

# ---------------- PARAMETERS ----------------
k = 8
WINDOW = 5000
STEP = 500

# ---------------- READ FASTA ----------------
genome = ""
for record in SeqIO.parse(FASTA_FILE, "fasta"):
    genome += str(record.seq).upper()

genome_len = len(genome)
print("Genome length:", genome_len)

# ---------------- K-MER COUNTER --------------
def count_kmers(seq, k):
    counts = Counter()
    for i in range(len(seq) - k + 1):
        kmer = seq[i:i+k]
        if "N" not in kmer:
            counts[kmer] += 1
    return counts

# -------- GENOME-WIDE BACKGROUND -------------
genome_kmers = count_kmers(genome, k)
total_genome_kmers = sum(genome_kmers.values())

genome_freq = {
    kmer: count / total_genome_kmers
    for kmer, count in genome_kmers.items()
}

# -------- SLIDING WINDOW ENRICHMENT ----------
max_enrichment = 0
best_region = (0, 0)

for start in range(0, genome_len - WINDOW + 1, STEP):
    end = start + WINDOW
    window_seq = genome[start:end]

    window_kmers = count_kmers(window_seq, k)
    total_window_kmers = sum(window_kmers.values())

    window_enrichment = 0

    for kmer, count in window_kmers.items():
        obs = count / total_window_kmers
        exp = genome_freq.get(kmer, 1e-10)
        window_enrichment += obs / exp

    if window_enrichment > max_enrichment:
        max_enrichment = window_enrichment
        best_region = (start, end)

# ---------------- OUTPUT ---------------------
print("\nMost enriched region (ORI candidate):")
print(f"Start: {best_region[0]}")
print(f"End:   {best_region[1]}")
print(f"Window enrichment score: {max_enrichment:.3f}")
